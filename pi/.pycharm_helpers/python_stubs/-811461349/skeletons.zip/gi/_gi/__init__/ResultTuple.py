# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc

# imports
import _glib as _glib # <module '_glib'>
import _gobject as _gobject # <module '_gobject'>
import gi as __gi
import gobject as __gobject


from .tuple import tuple

class ResultTuple(tuple):
    # no doc
    def _new_type(self, *args, **kwargs): # real signature unknown
        pass

    def __dir__(self, *args, **kwargs): # real signature unknown
        pass

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        """ Return getattr(self, name). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass


