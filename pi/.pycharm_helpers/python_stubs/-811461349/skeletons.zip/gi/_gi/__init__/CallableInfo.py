# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc

# imports
import _glib as _glib # <module '_glib'>
import _gobject as _gobject # <module '_gobject'>
import gi as __gi
import gobject as __gobject


class CallableInfo(__gi.BaseInfo):
    # no doc
    def can_throw_gerror(self, *args, **kwargs): # real signature unknown
        pass

    def get_arguments(self, *args, **kwargs): # real signature unknown
        pass

    def get_caller_owns(self, *args, **kwargs): # real signature unknown
        pass

    def get_return_attribute(self, *args, **kwargs): # real signature unknown
        pass

    def get_return_type(self, *args, **kwargs): # real signature unknown
        pass

    def invoke(self, *args, **kwargs): # real signature unknown
        pass

    def may_return_null(self, *args, **kwargs): # real signature unknown
        pass

    def skip_return(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


