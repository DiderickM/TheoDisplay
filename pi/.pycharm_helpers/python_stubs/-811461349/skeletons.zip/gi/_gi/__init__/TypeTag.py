# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc

# imports
import _glib as _glib # <module '_glib'>
import _gobject as _gobject # <module '_gobject'>
import gi as __gi
import gobject as __gobject


from .type import type

class TypeTag(type):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    ARRAY = 15
    BOOLEAN = 1
    DOUBLE = 11
    ERROR = 20
    FILENAME = 14
    FLOAT = 10
    GHASH = 19
    GLIST = 17
    GSLIST = 18
    GTYPE = 12
    INT16 = 4
    INT32 = 6
    INT64 = 8
    INT8 = 2
    INTERFACE = 16
    UINT16 = 5
    UINT32 = 7
    UINT64 = 9
    UINT8 = 3
    UNICHAR = 21
    UTF8 = 13
    VOID = 0


