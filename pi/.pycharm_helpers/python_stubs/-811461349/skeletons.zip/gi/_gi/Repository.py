# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc

# imports
import _gobject as _gobject # <module '_gobject'>
import _glib as _glib # <module '_glib'>
import gi as __gi
import gobject as __gobject


from .object import object

class Repository(object):
    # no doc
    def enumerate_versions(self, *args, **kwargs): # real signature unknown
        pass

    def find_by_name(self, *args, **kwargs): # real signature unknown
        pass

    def get_default(self, *args, **kwargs): # real signature unknown
        pass

    def get_dependencies(self, *args, **kwargs): # real signature unknown
        pass

    def get_immediate_dependencies(self, *args, **kwargs): # real signature unknown
        pass

    def get_infos(self, *args, **kwargs): # real signature unknown
        pass

    def get_loaded_namespaces(self, *args, **kwargs): # real signature unknown
        pass

    def get_typelib_path(self, *args, **kwargs): # real signature unknown
        pass

    def get_version(self, *args, **kwargs): # real signature unknown
        pass

    def is_registered(self, *args, **kwargs): # real signature unknown
        pass

    def require(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


