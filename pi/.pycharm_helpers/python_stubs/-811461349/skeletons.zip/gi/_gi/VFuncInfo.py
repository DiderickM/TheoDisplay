# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc

# imports
import _gobject as _gobject # <module '_gobject'>
import _glib as _glib # <module '_glib'>
import gi as __gi
import gobject as __gobject


class VFuncInfo(__gi.CallableInfo):
    # no doc
    def get_flags(self, *args, **kwargs): # real signature unknown
        pass

    def get_invoker(self, *args, **kwargs): # real signature unknown
        pass

    def get_offset(self, *args, **kwargs): # real signature unknown
        pass

    def get_signal(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


