# encoding: utf-8
# module rgbmatrix.graphics
# from /usr/local/lib/python3.5/dist-packages/rgbmatrix/graphics.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def DrawCircle(*args, **kwargs): # real signature unknown
    pass

def DrawLine(*args, **kwargs): # real signature unknown
    pass

def DrawText(*args, **kwargs): # real signature unknown
    pass

# classes

class Color(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    blue = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    green = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    red = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class Font(object):
    # no doc
    def CharacterWidth(self, *args, **kwargs): # real signature unknown
        pass

    def DrawGlyph(self, *args, **kwargs): # real signature unknown
        pass

    def LoadFont(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    baseline = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    height = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

__test__ = {}

