# encoding: utf-8
# module _codecs_hk
# from /usr/lib/python3.5/lib-dynload/_codecs_hk.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__map_big5hkscs = None # (!) real value is ''

__map_big5hkscs_bmp = None # (!) real value is ''

__map_big5hkscs_nonbmp = None # (!) real value is ''

__spec__ = None # (!) real value is ''

