# encoding: utf-8
# module PIL._imagingmath
# from /usr/lib/python3/dist-packages/PIL/_imagingmath.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

abs_F = 1986812856
abs_I = 1986809888

add_F = 1986813040
add_I = 1986810116

and_I = 1986811088

diff_F = 1986813496
diff_I = 1986810836

div_F = 1986813364
div_I = 1986810512

eq_F = 1986813840
eq_I = 1986812020

ge_F = 1986814520
ge_I = 1986812716

gt_F = 1986814384
gt_I = 1986812576

invert_I = 1986810976

le_F = 1986814248
le_I = 1986812436

lshift_I = 1986811484

lt_F = 1986814112
lt_I = 1986812296

max_F = 1986813724
max_I = 1986811884

min_F = 1986813608
min_I = 1986811748

mod_F = 1986814928
mod_I = 1986810672

mul_F = 1986813256
mul_I = 1986810380

neg_F = 1986812948
neg_I = 1986810004

ne_F = 1986813976
ne_I = 1986812160

or_I = 1986811220

pow_F = 1986815108
pow_I = 1986814656

rshift_I = 1986811616

sub_F = 1986813148
sub_I = 1986810248

xor_I = 1986811352

# functions

def binop(*args, **kwargs): # real signature unknown
    pass

def unop(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

