# encoding: utf-8
# module PIL._imagingft
# from /usr/lib/python3/dist-packages/PIL/_imagingft.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

freetype2_version = '2.6.3'

# functions

def getfont(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

