# encoding: utf-8
# module _codecs_jp
# from /usr/lib/python3.5/lib-dynload/_codecs_jp.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__map_cp932ext = None # (!) real value is ''

__map_jisx0208 = None # (!) real value is ''

__map_jisx0212 = None # (!) real value is ''

__map_jisx0213_1_bmp = None # (!) real value is ''

__map_jisx0213_1_emp = None # (!) real value is ''

__map_jisx0213_2_bmp = None # (!) real value is ''

__map_jisx0213_2_emp = None # (!) real value is ''

__map_jisx0213_bmp = None # (!) real value is ''

__map_jisx0213_emp = None # (!) real value is ''

__map_jisx0213_pair = None # (!) real value is ''

__map_jisxcommon = None # (!) real value is ''

__spec__ = None # (!) real value is ''

