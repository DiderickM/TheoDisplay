# encoding: utf-8
# module cython_runtime
# from /usr/local/lib/python3.5/dist-packages/rgbmatrix/graphics.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

__loader__ = None

__spec__ = None

# no functions
# no classes
