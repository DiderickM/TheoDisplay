# encoding: utf-8
# module Crypto.Cipher._XOR
# from /usr/lib/python3/dist-packages/Crypto/Cipher/_XOR.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

block_size = 1

error = '_XOR.error'

key_size = 0

# functions

def new(*args, **kwargs): # real signature unknown
    """ Return a new _XOR encryption object. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

