# encoding: utf-8
# module Crypto.Cipher._Blowfish
# from /usr/lib/python3/dist-packages/Crypto/Cipher/_Blowfish.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

block_size = 8

key_size = 0

MODE_CBC = 2
MODE_CFB = 3
MODE_CTR = 6
MODE_ECB = 1
MODE_OFB = 5
MODE_PGP = 4

# functions

def new(key, mode=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ new(key, [mode], [IV]): Return a new _Blowfish encryption object. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

