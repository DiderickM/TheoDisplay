# encoding: utf-8
# module Crypto.Util._counter
# from /usr/lib/python3/dist-packages/Crypto/Util/_counter.cpython-35m-arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# functions

def _newBE(*args, **kwargs): # real signature unknown
    pass

def _newLE(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

