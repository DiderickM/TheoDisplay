# encoding: utf-8
# module rgbmatrix.graphics
# from /usr/local/lib/python2.7/dist-packages/rgbmatrix/graphics.so
# by generator 1.145
# no doc

# imports
import __builtin__ as __builtins__ # <module '__builtin__' (built-in)>

# functions

def DrawCircle(*args, **kwargs): # real signature unknown
    pass

def DrawLine(*args, **kwargs): # real signature unknown
    pass

def DrawText(*args, **kwargs): # real signature unknown
    pass

# classes

class Color(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    blue = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    green = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    red = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class Font(object):
    # no doc
    def CharacterWidth(self, *args, **kwargs): # real signature unknown
        pass

    def DrawGlyph(self, *args, **kwargs): # real signature unknown
        pass

    def LoadFont(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    baseline = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    height = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



# variables with complex values

__test__ = {}

