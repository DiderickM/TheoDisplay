# encoding: utf-8
# module dbm
# from /usr/lib/python2.7/lib-dynload/dbm.arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

library = 'Berkeley DB'

# functions

def open(path, flag=None, mode=None): # real signature unknown; restored from __doc__
    """
    open(path[, flag[, mode]]) -> mapping
    Return a database object.
    """
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



