# encoding: utf-8
# module PIL._imaging
# from /usr/lib/python2.7/dist-packages/PIL/_imaging.arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

DEFAULT_STRATEGY = 0

FILTERED = 1
FIXED = 4

HUFFMAN_ONLY = 2

jpeglib_version = '6.2'

PILLOW_VERSION = '4.0.0'

RLE = 3

zlib_version = '1.2.8'

# functions

def alpha_composite(*args, **kwargs): # real signature unknown
    pass

def bcn_decoder(*args, **kwargs): # real signature unknown
    pass

def bit_decoder(*args, **kwargs): # real signature unknown
    pass

def blend(*args, **kwargs): # real signature unknown
    pass

def convert(*args, **kwargs): # real signature unknown
    pass

def copy(*args, **kwargs): # real signature unknown
    pass

def crc32(*args, **kwargs): # real signature unknown
    pass

def draw(*args, **kwargs): # real signature unknown
    pass

def effect_mandelbrot(*args, **kwargs): # real signature unknown
    pass

def effect_noise(*args, **kwargs): # real signature unknown
    pass

def eps_encoder(*args, **kwargs): # real signature unknown
    pass

def fill(*args, **kwargs): # real signature unknown
    pass

def fli_decoder(*args, **kwargs): # real signature unknown
    pass

def font(*args, **kwargs): # real signature unknown
    pass

def getcodecstatus(*args, **kwargs): # real signature unknown
    pass

def getcount(*args, **kwargs): # real signature unknown
    pass

def gif_decoder(*args, **kwargs): # real signature unknown
    pass

def gif_encoder(*args, **kwargs): # real signature unknown
    pass

def hex_decoder(*args, **kwargs): # real signature unknown
    pass

def hex_encoder(*args, **kwargs): # real signature unknown
    pass

def jpeg_decoder(*args, **kwargs): # real signature unknown
    pass

def jpeg_encoder(*args, **kwargs): # real signature unknown
    pass

def libtiff_decoder(*args, **kwargs): # real signature unknown
    pass

def libtiff_encoder(*args, **kwargs): # real signature unknown
    pass

def linear_gradient(*args, **kwargs): # real signature unknown
    pass

def map_buffer(*args, **kwargs): # real signature unknown
    pass

def msp_decoder(*args, **kwargs): # real signature unknown
    pass

def new(*args, **kwargs): # real signature unknown
    pass

def outline(*args, **kwargs): # real signature unknown
    pass

def packbits_decoder(*args, **kwargs): # real signature unknown
    pass

def path(*args, **kwargs): # real signature unknown
    pass

def pcd_decoder(*args, **kwargs): # real signature unknown
    pass

def pcx_decoder(*args, **kwargs): # real signature unknown
    pass

def pcx_encoder(*args, **kwargs): # real signature unknown
    pass

def radial_gradient(*args, **kwargs): # real signature unknown
    pass

def raw_decoder(*args, **kwargs): # real signature unknown
    pass

def raw_encoder(*args, **kwargs): # real signature unknown
    pass

def sun_rle_decoder(*args, **kwargs): # real signature unknown
    pass

def tga_rle_decoder(*args, **kwargs): # real signature unknown
    pass

def tiff_lzw_decoder(*args, **kwargs): # real signature unknown
    pass

def wedge(*args, **kwargs): # real signature unknown
    pass

def xbm_decoder(*args, **kwargs): # real signature unknown
    pass

def xbm_encoder(*args, **kwargs): # real signature unknown
    pass

def zip_decoder(*args, **kwargs): # real signature unknown
    pass

def zip_encoder(*args, **kwargs): # real signature unknown
    pass

# no classes
