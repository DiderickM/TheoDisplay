# encoding: utf-8
# module PIL._webp
# from /usr/lib/python2.7/dist-packages/PIL/_webp.arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

HAVE_WEBPMUX = True

# functions

def WebPDecode(*args, **kwargs): # real signature unknown
    """ WebPDecode """
    pass

def WebPDecoderBuggyAlpha(*args, **kwargs): # real signature unknown
    """ WebPDecoderBuggyAlpha """
    pass

def WebPDecoderVersion(*args, **kwargs): # real signature unknown
    """ WebPVersion """
    pass

def WebPEncode(*args, **kwargs): # real signature unknown
    """ WebPEncode """
    pass

# no classes
