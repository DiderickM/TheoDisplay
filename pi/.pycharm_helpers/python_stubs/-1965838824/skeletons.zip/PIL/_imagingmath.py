# encoding: utf-8
# module PIL._imagingmath
# from /usr/lib/python2.7/dist-packages/PIL/_imagingmath.arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

abs_F = -1231852908
abs_I = -1231855600

add_F = -1231852708
add_I = -1231855388

and_I = -1231854520

diff_F = -1231852236
diff_I = -1231854752

div_F = -1231852372
div_I = -1231855028

eq_F = -1231851880
eq_I = -1231853672

ge_F = -1231851180
ge_I = -1231853036

gt_F = -1231851320
gt_I = -1231853164

invert_I = -1231854624

le_F = -1231851460
le_I = -1231853292

lshift_I = -1231854160

lt_F = -1231851600
lt_I = -1231853420

max_F = -1231852000
max_I = -1231853796

min_F = -1231852120
min_I = -1231853920

mod_F = -1231850768
mod_I = -1231854892

mul_F = -1231852484
mul_I = -1231855148

neg_F = -1231852808
neg_I = -1231855492

ne_F = -1231851740
ne_I = -1231853544

or_I = -1231854400

pow_F = -1231850588
pow_I = -1231851040

rshift_I = -1231854040

sub_F = -1231852596
sub_I = -1231855268

xor_I = -1231854280

# functions

def binop(*args, **kwargs): # real signature unknown
    pass

def unop(*args, **kwargs): # real signature unknown
    pass

# no classes
