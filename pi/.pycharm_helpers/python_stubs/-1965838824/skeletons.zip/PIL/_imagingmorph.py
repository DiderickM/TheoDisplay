# encoding: utf-8
# module PIL._imagingmorph
# from /usr/lib/python2.7/dist-packages/PIL/_imagingmorph.arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

__version = '0.1'

# functions

def apply(*args, **kwargs): # real signature unknown
    pass

def get_on_pixels(*args, **kwargs): # real signature unknown
    pass

def match(*args, **kwargs): # real signature unknown
    pass

# no classes
