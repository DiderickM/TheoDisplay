# encoding: utf-8
# module PIL._imagingft
# from /usr/lib/python2.7/dist-packages/PIL/_imagingft.arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

freetype2_version = '2.6.3'

# functions

def getfont(*args, **kwargs): # real signature unknown
    pass

# no classes
