# encoding: utf-8
# module _sha
# from (built-in)
# by generator 1.145
# no doc
# no imports

# Variables with simple values

blocksize = 1

digestsize = 20

digest_size = 20

# functions

def new(*args, **kwargs): # real signature unknown
    """
    Return a new SHA hashing object.  An optional string argument
    may be provided; if present, this string will be automatically
    hashed.
    """
    pass

# no classes
