# encoding: utf-8
# module _codecs_cn
# from /usr/lib/python2.7/lib-dynload/_codecs_cn.arm-linux-gnueabihf.so
# by generator 1.145
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
# variables with complex values

__map_gb18030ext = None # (!) real value is ''

__map_gb2312 = None # (!) real value is ''

__map_gbcommon = None # (!) real value is ''

__map_gbkext = None # (!) real value is ''

